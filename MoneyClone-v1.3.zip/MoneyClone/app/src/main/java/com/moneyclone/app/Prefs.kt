package com.moneyclone.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Clone(val pkg: String, val name: String)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("mc", 0)
    fun clones(c: Context): List<Clone> {
        val a = JSONArray(sp(c).getString("clones", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> Clone(o.getString("p"), o.getString("n")) } }
    }
    private fun save(c: Context, l: List<Clone>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("p", it.pkg).put("n", it.name)) }
        sp(c).edit().putString("clones", a.toString()).apply()
    }
    fun add(c: Context, cl: Clone) = save(c, clones(c) + cl)
    fun remove(c: Context, pkg: String) = save(c, clones(c).filter { it.pkg != pkg })
    fun rename(c: Context, pkg: String, n: String) = save(c, clones(c).map { if (it.pkg == pkg) it.copy(name = n) else it })
    fun bool(c: Context, k: String, d: Boolean = false) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
}
