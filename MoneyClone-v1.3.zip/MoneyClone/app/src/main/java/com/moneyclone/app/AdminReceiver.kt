package com.moneyclone.app
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    // Runs inside the new work profile once Android finishes creating it.
    override fun onProfileProvisioningComplete(c: Context, i: Intent) {
        val dpm = c.getSystemService(DevicePolicyManager::class.java)
        val me = ComponentName(c, AdminReceiver::class.java)
        dpm.setProfileName(me, "MoneyClone")
        dpm.setProfileEnabled(me)
    }
}
