package com.moneyclone.app
import android.content.Intent
import android.content.pm.LauncherApps
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import android.app.ActivityManager
import android.view.WindowManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.fragment.app.FragmentActivity

private val Accents = listOf(Color(0xFF4ADE80), Color(0xFF38BDF8), Color(0xFFA78BFA), Color(0xFFFB923C))
private fun scheme(dark: Boolean, a: Color) = if (dark) darkColorScheme(
    primary = a, onPrimary = Color(0xFF00110A), primaryContainer = a.copy(alpha = 0.22f), onPrimaryContainer = a,
    background = Color(0xFF0B1210), surface = Color(0xFF0B1210), onSurface = Color(0xFFE6F2EC),
    surfaceVariant = Color(0xFF16211D), onSurfaceVariant = Color(0xFF9DB5A9), error = Color(0xFFFF6B6B))
else lightColorScheme(
    primary = a, onPrimary = Color.Black, primaryContainer = a.copy(alpha = 0.25f), onPrimaryContainer = Color(0xFF111A16),
    background = Color(0xFFF3F7F5), surface = Color(0xFFF3F7F5), onSurface = Color(0xFF111A16),
    surfaceVariant = Color(0xFFE3ECE8), onSurfaceVariant = Color(0xFF51635A), error = Color(0xFFD32F2F))

class MainActivity : FragmentActivity() {
    private var unlocked by mutableStateOf(false)
    private var tick by mutableStateOf(0)
    private var dark by mutableStateOf(true)
    private var accent by mutableStateOf(0)
    private val eng: CloneEngine = WorkProfileEngine

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        intent.getStringExtra("launch_pkg")?.let { eng.open(this, it); finish(); return }
        dark = Prefs.bool(this, "dark", true); accent = Prefs.int(this, "accent", 0)
        if (Prefs.bool(this, "incog")) applyIncognito(true)
        if (Prefs.bool(this, "lock")) askFinger() else unlocked = true
        setContent { MaterialTheme(colorScheme = scheme(dark, Accents[accent])) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (unlocked) Root() else LockScreen()
        } } }
    }
    override fun onResume() { super.onResume(); tick++ }

    private fun askFinger() {
        val p = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { unlocked = true }
        })
        p.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("MoneyClone").setNegativeButtonText("Cancel").build())
    }
    private fun applyIncognito(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE) else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        getSystemService(ActivityManager::class.java).appTasks.forEach { it.setExcludeFromRecents(on) }
    }
    private fun repair() {
        val pm = getSystemService(PowerManager::class.java)
        when {
            !eng.ready(this) -> eng.setup(this)
            !pm.isIgnoringBatteryOptimizations(packageName) -> go(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            !Settings.canDrawOverlays(this) -> go(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            else -> { if (Prefs.bool(this, "auto")) KeepAliveService.start(this, false); toast("All good. Keep-alive restarted.") }
        }
    }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun go(a: String) = startActivity(Intent(a, Uri.parse("package:$packageName")))
    private fun launchAll(l: List<Clone>) {
        val h = Handler(Looper.getMainLooper())
        val run = l.filter { Prefs.bool(this, "as_" + it.pkg, true) }
        run.forEachIndexed { i, c -> h.postDelayed({ eng.open(this, c.pkg) }, i * 1500L) }
        toast("Launching ${run.size} clones")
    }
    private fun loadApps(): List<Pair<String, String>> {
        val la = getSystemService(LauncherApps::class.java)
        return la.profiles.flatMap { u -> la.getActivityList(null, u) }
            .map { Pair(it.label.toString(), it.applicationInfo.packageName) }
            .filter { it.second != packageName }.distinctBy { it.second }.sortedBy { it.first.lowercase() }
    }

    @Composable fun LockScreen() = Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🔒", fontSize = 56.sp); Spacer(Modifier.height(12.dp))
        Text("MoneyClone is locked", fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(20.dp))
        Button({ askFinger() }) { Text("Unlock with fingerprint") }
    }

    @Composable fun Avatar(name: String) = Box(Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), Alignment.Center) {
        Text(name.take(1).uppercase(), color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
    }
    @Composable fun Panel(content: @Composable ColumnScope.() -> Unit) = Card(Modifier.fillMaxWidth(), RoundedCornerShape(22.dp),
        CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) { Column(Modifier.padding(16.dp), content = content) }

    @Composable fun Root() {
        var tab by remember { mutableStateOf(0) }
        var clones by remember { mutableStateOf(Prefs.clones(this)) }
        val apps = remember { loadApps() }
        val reload = { clones = Prefs.clones(this) }
        Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                listOf("🏠" to "Home", "➕" to "Apps", "📋" to "Clones", "⚙️" to "Settings").forEachIndexed { i, (e, l) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(e, fontSize = 20.sp) }, label = { Text(l) })
                }
            }
        }) { pad -> Box(Modifier.padding(pad).fillMaxSize()) { when (tab) {
            0 -> HomeTab(clones) { tab = it }
            1 -> AppsTab(apps, clones, reload)
            2 -> ClonesTab(clones, reload)
            else -> SettingsTab(clones)
        } } }
    }

    @Composable fun HomeTab(clones: List<Clone>, nav: (Int) -> Unit) {
        val t = tick
        val pm = getSystemService(PowerManager::class.java)
        val space = eng.ready(this); val bat = pm.isIgnoringBatteryOptimizations(packageName); val ov = Settings.canDrawOverlays(this)
        val score = listOf(space, bat, ov).count { it }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("MoneyClone", fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("PREMIUM", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, letterSpacing = 3.sp) }
            item { Panel {
                Text("Setup health", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$score / 3 ready", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress = { score / 3f }, Modifier.fillMaxWidth().height(8.dp).clip(CircleShape))
                Spacer(Modifier.height(8.dp))
                Check("Clone space", space, "Set up") { eng.setup(this@MainActivity) }
                Check("Unrestricted battery", bat, "Allow") { go(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS) }
                Check("Run in background (overlay)", ov, "Allow") { go(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) }
                Spacer(Modifier.height(6.dp)); FilledTonalButton({ repair() }, Modifier.fillMaxWidth()) { Text("🛠  One-key repair") }
            } }
            item { Panel {
                Text("${clones.size} clones", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Keep-alive: ${if (Prefs.bool(this@MainActivity, "auto")) "ON" else "OFF"}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Button({ launchAll(clones) }, Modifier.fillMaxWidth(), enabled = clones.isNotEmpty()) { Text("▶  Launch all clones") }
                TextButton({ nav(1) }, Modifier.fillMaxWidth()) { Text("➕  Add a clone") }
            } }
        }
    }
    @Composable fun Check(title: String, ok: Boolean, fix: String, act: () -> Unit) = Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (ok) "✅" else "⚠️"); Spacer(Modifier.width(10.dp)); Text(title, Modifier.weight(1f))
        if (!ok) FilledTonalButton(act) { Text(fix) }
    }

    @Composable fun AppsTab(apps: List<Pair<String, String>>, clones: List<Clone>, reload: () -> Unit) {
        var q by remember { mutableStateOf("") }
        Column {
            if (!WorkProfileEngine.isWork(this@MainActivity)) Box(Modifier.padding(16.dp, 16.dp, 16.dp, 0.dp)) { Panel {
                Text("You are in the MAIN copy. Cloning only works inside the work copy.", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Button({ if (!WorkProfileEngine.openWorkCopy(this@MainActivity)) toast("Work copy not found. Go to Home → Set up clone space.") }, Modifier.fillMaxWidth()) { Text("Open work copy of MoneyClone") }
            } }
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp), placeholder = { Text("Search apps") }, singleLine = true, shape = RoundedCornerShape(16.dp))
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(apps.filter { it.first.contains(q, true) }) { a ->
                    val done = clones.any { it.pkg == a.second }
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(a.first); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(a.first, fontWeight = FontWeight.Medium); Text(a.second, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) }
                        Button({
                            val r = eng.create(this@MainActivity, a.second)
                            if (r == "Cloned") { Prefs.add(this@MainActivity, Clone(a.second, a.first + " clone")); reload() }
                            toast(r)
                        }, enabled = !done) { Text(if (done) "Cloned ✓" else "Clone") }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }

    @Composable fun ClonesTab(clones: List<Clone>, reload: () -> Unit) {
        var rename by remember { mutableStateOf<Clone?>(null) }
        var del by remember { mutableStateOf<Clone?>(null) }
        if (clones.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No clones yet.\nGo to Apps and tap Clone.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(clones) { c ->
                var keep by remember(c.pkg) { mutableStateOf(Prefs.bool(this@MainActivity, "as_" + c.pkg, true)) }
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) { Avatar(c.name); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(c.name, fontWeight = FontWeight.SemiBold); Text(c.pkg, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1) } }
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("Auto-start & keep alive", Modifier.weight(1f), fontSize = 13.sp)
                        Switch(keep, { keep = it; Prefs.setBool(this@MainActivity, "as_" + c.pkg, it) }) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ eng.open(this@MainActivity, c.pkg) }) { Text("Open") }
                        FilledTonalButton({ rename = c }) { Text("Rename") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton({ startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.pkg}"))) }) { Text("App info / Stop") }
                        TextButton({ del = c }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
        rename?.let { c -> var t by remember { mutableStateOf(c.name) }
            AlertDialog({ rename = null }, title = { Text("Rename clone") }, text = { OutlinedTextField(t, { t = it }) },
                confirmButton = { TextButton({ Prefs.rename(this@MainActivity, c.pkg, t); reload(); rename = null }) { Text("Save") } }) }
        del?.let { c -> AlertDialog({ del = null }, title = { Text("Delete ${c.name}?") }, text = { Text("Its data in the clone space may be lost.") },
            confirmButton = { TextButton({ eng.delete(this@MainActivity, c.pkg); Prefs.remove(this@MainActivity, c.pkg); reload(); del = null }) { Text("Delete") } },
            dismissButton = { TextButton({ del = null }) { Text("Cancel") } }) }
    }

    @Composable fun SettingsTab(clones: List<Clone>) {
        var auto by remember { mutableStateOf(Prefs.bool(this, "auto")) }
        var lock by remember { mutableStateOf(Prefs.bool(this, "lock")) }
        var incog by remember { mutableStateOf(Prefs.bool(this, "incog")) }
        var bubble by remember { mutableStateOf(Prefs.bool(this, "bubble")) }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
            item { Panel {
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Auto-start all clones"); Text("Runs at boot, keeps service alive", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Switch(auto, { auto = it; Prefs.setBool(this@MainActivity, "auto", it); if (it) KeepAliveService.start(this@MainActivity, false) else KeepAliveService.stop(this@MainActivity) }) }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Fingerprint lock"); Text("Ask fingerprint to open MoneyClone", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Switch(lock, { lock = it; Prefs.setBool(this@MainActivity, "lock", it) }) }
            } }
            item { Panel {
                Text("Appearance & privacy", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Dark mode", Modifier.weight(1f)); Switch(dark, { dark = it; Prefs.setBool(this@MainActivity, "dark", it) }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Theme color", Modifier.weight(1f))
                    Accents.forEachIndexed { i, c -> Box(Modifier.padding(start = 10.dp).size(30.dp).clip(CircleShape).background(c).clickable { accent = i; Prefs.setInt(this@MainActivity, "accent", i) }) } }
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Incognito mode"); Text("Hides MoneyClone in Recents, blocks screenshots", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Switch(incog, { incog = it; Prefs.setBool(this@MainActivity, "incog", it); applyIncognito(it) }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Bubble mode"); Text("Floating 💰 button to open clones from any screen", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    Switch(bubble, { on ->
                        if (on && !Settings.canDrawOverlays(this@MainActivity)) { toast("Allow display over other apps first"); go(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) }
                        else { bubble = on; Prefs.setBool(this@MainActivity, "bubble", on)
                            val i = Intent(this@MainActivity, BubbleService::class.java); if (on) startService(i) else stopService(i) } }) }
            } }
            item { Panel {
                Text("Background permissions", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(8.dp))
                FilledTonalButton({ go(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS) }, Modifier.fillMaxWidth()) { Text("1. Unrestricted battery") }
                FilledTonalButton({ go(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) }, Modifier.fillMaxWidth()) { Text("2. Display over other apps") }
                FilledTonalButton({ go(Settings.ACTION_APPLICATION_DETAILS_SETTINGS) }, Modifier.fillMaxWidth()) { Text("3. App info → Autostart") }
            } }
            item { Panel {
                FilledTonalButton({ startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("🧹  Storage cleaner") }
                Button({ clones.forEach { c -> ShortcutManagerCompat.requestPinShortcut(this@MainActivity, ShortcutInfoCompat.Builder(this@MainActivity, c.pkg)
                    .setShortLabel(c.name).setIcon(IconCompat.createWithResource(this@MainActivity, android.R.drawable.sym_def_app_icon))
                    .setIntent(Intent(this@MainActivity, MainActivity::class.java).setAction(Intent.ACTION_MAIN).putExtra("launch_pkg", c.pkg)).build(), null) } },
                    Modifier.fillMaxWidth(), enabled = clones.isNotEmpty()) { Text("Add clone shortcuts to home screen") }
            } }
            item { Text("MoneyClone 1.2 • work-profile engine (1 clone per app)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
