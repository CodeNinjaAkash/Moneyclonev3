package com.moneyclone.app
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserManager

/** Plug-in point: later add VirtualEngine for 15+ copies of one app. */
interface CloneEngine {
    fun ready(c: Context): Boolean
    fun setup(a: Activity)
    fun create(c: Context, pkg: String): String   // returns status message
    fun open(c: Context, pkg: String)
    fun delete(c: Context, pkg: String)
}

object WorkProfileEngine : CloneEngine {
    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)
    private fun dpm(c: Context) = c.getSystemService(DevicePolicyManager::class.java)
    private fun other(c: Context) = c.getSystemService(UserManager::class.java).userProfiles.firstOrNull { it != Process.myUserHandle() }
    private fun inProfile(c: Context) = dpm(c).isProfileOwnerApp(c.packageName)

    fun isWork(c: Context) = inProfile(c)
    fun openWorkCopy(c: Context): Boolean {
        val la = c.getSystemService(LauncherApps::class.java)
        val u = other(c) ?: return false
        val a = la.getActivityList(c.packageName, u).firstOrNull() ?: return false
        la.startMainActivity(a.componentName, u, null, null); return true
    }

    override fun ready(c: Context) = other(c) != null || inProfile(c)

    override fun setup(a: Activity) {
        val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
            .putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin(a))
        a.startActivityForResult(i, 1)
    }

    override fun create(c: Context, pkg: String): String {
        if (!inProfile(c)) return "Open the MoneyClone copy inside your work profile (briefcase icon) and clone from there."
        return try {
            dpm(c).installExistingPackage(admin(c), pkg); "Cloned"
        } catch (e: Exception) { "Failed: ${e.message}" }
    }

    override fun open(c: Context, pkg: String) {
        val la = c.getSystemService(LauncherApps::class.java)
        val u = other(c) ?: Process.myUserHandle()
        la.getActivityList(pkg, u).firstOrNull()?.let { la.startMainActivity(it.componentName, u, null, null) }
    }

    override fun delete(c: Context, pkg: String) {
        if (inProfile(c)) try { dpm(c).setApplicationHidden(admin(c), pkg, true) } catch (_: Exception) {}
    }
}
